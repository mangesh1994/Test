package com.epic.context;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpicContextApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpicContextApplication.class, args);
	}

}
